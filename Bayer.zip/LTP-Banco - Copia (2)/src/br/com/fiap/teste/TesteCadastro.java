package br.com.fiap.teste;

import br.com.fiap.bean.Nutricionista;
import br.com.fiap.bean.Professor;
import br.com.fiap.dao.OracleNutricionistaDAO;
import br.com.fiap.dao.OracleProfessorDAO;

import java.util.Calendar;

public class TesteCadastro {

    public static void main(String[] args) {
        //Instancia DAO
        OracleProfessorDAO dao = new OracleProfessorDAO();

        //instancia nutricionista
        Professor professor = new Professor();
        professor.setNome("Victoria");
        professor.setCref(2132);

        //cadastrar no banco
        dao.insert(professor);

        System.out.println("Cadastrado!");
    }

}
